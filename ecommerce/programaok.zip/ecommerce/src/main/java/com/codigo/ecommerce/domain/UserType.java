package com.codigo.ecommerce.domain;

public enum UserType {
    ADMIN, USER
}
